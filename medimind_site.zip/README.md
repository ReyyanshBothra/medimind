# Medimind 🌿
A visual + auditory meditation app built with React and TailwindCSS.

## 🌐 Deploy to GitHub Pages
1. Create a public repo named `medimind`.
2. Upload this `index.html` to the root of the repo.
3. Go to **Settings → Pages → Deploy from branch → main → /(root)**.
4. Your site will appear at: https://<your-username>.github.io/medimind/

Enjoy meditating with fractals and golden ratio spirals ✨
